#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <mainwindow.h>
#include "ui_mainwindow.h"
// #include "loginwindow.h"
#include "schedule.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow) {

    ui->setupUi(this);
    setWindowTitle("광산구청 통합관리 시스템");



    // connect(ui->pushButton_3, &QPushButton::clicked, this, &MainWindow::changeSchedulePage);
}

MainWindow::~MainWindow() {
    delete ui;
}


